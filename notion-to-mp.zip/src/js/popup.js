document.addEventListener('DOMContentLoaded', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const isNotion = tab?.url?.includes('notion.so');

  if (isNotion) {
    try {
      // 发送 ping 消息检查页面状态
      chrome.tabs.sendMessage(tab.id, { action: 'ping' }, (response) => {
        if (chrome.runtime.lastError || !response) {
          // 页面需要刷新
          showError('页面需要刷新才能使用插件', tab);
        } else {
          // 页面状态正常，注入侧边栏
          chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ['/src/js/injectSidebar.js']
          });
          window.close();
        }
      });
    } catch (error) {
      showError('插件加载失败，请刷新页面重试', tab);
    }
  }
});

function showError(message, tab) {
  const errorContainer = document.createElement('div');
  errorContainer.style.cssText = `
    width: 300px;
    padding: 24px;
    background: white;
    text-align: center;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  `;
  
  errorContainer.innerHTML = `
    <div style="margin-bottom: 16px;">
      <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M24 4C12.96 4 4 12.96 4 24C4 35.04 12.96 44 24 44C35.04 44 44 35.04 44 24C44 12.96 35.04 4 24 4ZM26 34H22V30H26V34ZM26 26H22V14H26V26Z" 
              fill="#FFA726"/>
      </svg>
    </div>
    <h2 style="
      margin: 0 0 8px;
      color: #1a1a1a;
      font-size: 16px;
      font-weight: 600;
    ">需要刷新页面</h2>
    <p style="
      margin: 0 0 20px;
      color: #666;
      font-size: 14px;
      line-height: 1.5;
    ">${message}</p>
    <button id="reloadButton" style="
      background: #2eaadc;
      color: white;
      border: none;
      padding: 8px 24px;
      border-radius: 4px;
      font-size: 14px;
      font-weight: 500;
      cursor: pointer;
      transition: background 0.2s;
    ">刷新页面</button>
  `;
  
  document.body.innerHTML = '';
  document.body.style.margin = '0';
  document.body.style.background = '#f5f5f5';
  document.body.appendChild(errorContainer);
  
  const reloadButton = document.getElementById('reloadButton');
  reloadButton.addEventListener('mouseover', () => {
    reloadButton.style.background = '#2596c4';
  });
  reloadButton.addEventListener('mouseout', () => {
    reloadButton.style.background = '#2eaadc';
  });
  
  reloadButton.addEventListener('click', () => {
    chrome.tabs.reload(tab.id);
    window.close();
  });
}