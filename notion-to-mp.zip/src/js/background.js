chrome.runtime.onInstalled.addListener(() => {
  console.log('Extension installed');
});

// 监听来自 popup 的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getContent') {
    // 转发消息到 content script
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      if (!tabs[0]) {
        sendResponse({ error: '无法获取当前标签页' });
        return;
      }

      try {
        // 确保 content script 已注入
        await chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          files: ['/src/js/content.js']
        });

        // 发送消息到 content script
        chrome.tabs.sendMessage(tabs[0].id, request, (response) => {
          if (chrome.runtime.lastError) {
            console.error('Error:', chrome.runtime.lastError);
            sendResponse({ error: '无法连接到页面，请刷新后重试' });
          } else {
            sendResponse(response);
          }
        });
      } catch (error) {
        console.error('Error:', error);
        sendResponse({ error: '脚本注入失败，请刷新页面重试' });
      }
    });
    return true; // 保持消息通道开放
  }
});