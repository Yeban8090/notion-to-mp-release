
// 使用 window 对象来避免重复声明
if (!window.notionContentExtractor) {
  window.notionContentExtractor = {
    getPageContent() {
      try {
        // 获取正文内容
        const blocks = Array.from(document.querySelectorAll([
          '.notion-text-block',                    // 文本
          '.notion-header-block',                  // 一级标题
          '.notion-sub_header-block',              // 二级标题
          '.notion-sub_sub_header-block',          // 三级标题
          '.notion-bulleted_list-block',           // 无序列表
          '.notion-numbered_list-block',           // 有序列表
          '.line-numbers.notion-code-block',       // 代码块
          '.notion-quote-block',                   // 引用
          '.notion-image-block',                   // 图片
          '.notion-table-block',                   // 表格
          '.notion-divider-block'                  // 分割线
        ].join(', ')));
    
       
        // 检查内容是否为空
        if (!blocks.length) {
          sendResponse({ error: '页面内容未完全加载，请等待页面加载完成后重试。' });
          return true;
        }
        // 创建容器保存内容
        const container = document.createElement('div');
        
        blocks.forEach((block, index) => {
          try {            
            const clonedBlock = block.cloneNode(true);
            container.appendChild(clonedBlock);
          } catch (blockError) {
            console.error(`处理第 ${index + 1} 个块时出错:`, blockError);
          }
        });
    
        
        return container.innerHTML;
      } catch (error) {
        console.error('获取页面内容时出错:', error);
        return null;
      }
    }
  };

  // 只在第一次加载时添加消息监听器
  // 在消息监听器中添加 ping 处理
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'ping') {
      sendResponse(true);
      return true;
    }
    if (request.action === 'getContent') {
      try {
        // 获取原始内容
        let content = window.notionContentExtractor.getPageContent();
        // 转换格式
        content = window.FormatConverter.convertNotionToWechat(content);
        if (content) {
          sendResponse({ content });
        } else {
          sendResponse({ error: '无法找到 Notion 页面内容' });
        }
      } catch (error) {
        sendResponse({ error: '处理内容时发生错误: ' + error.message });
      }
      console.log('content中getContent已加载');
    }
    return true;
  });
}