import themeManager, { themes } from '/src/js/themeManager.js';
import '/src/js/previewConverter.js';

document.addEventListener('DOMContentLoaded', async () => {
  // 初始化主题选择器
  const themeSelect = document.getElementById('themeSelect');
  Object.keys(themes).forEach(themeName => {
    const option = document.createElement('option');
    option.value = themeName;
    option.textContent = themes[themeName].name;
    themeSelect.appendChild(option);
  });

  // 初始化变量
  const fontSelect = document.getElementById('fontSelect');
  const decreaseFont = document.getElementById('decreaseFont');
  const increaseFont = document.getElementById('increaseFont');
  const fontSizeDisplay = document.getElementById('fontSize');
  const copyButton = document.getElementById('copyButton');
  const preview = document.getElementById('preview');
  let fontSize = 16;

  // 获取内容并显示
  // 添加变量保存原始内容
  let pageContent = '';

    // 初始化时获取内容
    async function initialize() {
      pageContent = await fetchContent();
      if (pageContent) {
        updatePreview();
      }
    }

  // 获取内容的函数
  async function fetchContent() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab) {
        showError('无法获取当前标签页');
        return null;
      }
      
      return new Promise((resolve) => {
        chrome.runtime.sendMessage({ 
          action: 'getContent',
          tabId: tab.id 
        }, response => {
          if (response?.content) {
            resolve(response.content);
          } else {
            showError(response?.error || '无法获取页面内容');
            resolve(null);
          }
        });
      });
    } catch (error) {
      console.error('获取内容失败:', error);
      showError('获取内容时发生错误');
      return null;
    }
  }

  function showError(message) {
    const preview = document.getElementById('preview');
    preview.innerHTML = `
      <div class="error-message" style="
        text-align: center;
        padding: 20px;
        color: #666;
        line-height: 1.6;
        background: #fff3f3;
        border-radius: 8px;
        margin: 20px;
      ">
        <div style="margin-bottom: 15px;">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"></circle>
            <line x1="12" y1="8" x2="12" y2="12"></line>
            <line x1="12" y1="16" x2="12.01" y2="16"></line>
          </svg>
        </div>
        <h3 style="margin: 0 0 10px; font-size: 16px;">${message}</h3>
        <p style="margin: 0;">请尝试刷新页面后重试</p>
      </div>
    `;
  }

  // 修改 initialize 函数
  async function initialize() {
    const content = await fetchContent();
    if (content) {
      pageContent = content;
      updatePreview();
    }
  }

  // 更新预览的函数，不再获取内容
  function updatePreview() {
    if (pageContent) {
      preview.innerHTML = pageContent;
      themeManager.setFontSize(fontSize);
      themeManager.applyThemeToElement(preview);
    }
  }

  // 修改复制按钮事件处理
  copyButton.addEventListener('click', async () => {
    try {
      copyButton.disabled = true;
      copyButton.textContent = '复制中...';
      
      const success = await window.PreviewConverter.copyWithFormat(preview.innerHTML);
      
      copyButton.textContent = success ? '复制成功！' : '复制失败';
      setTimeout(() => {
        copyButton.textContent = '复制为公众号格式';
        copyButton.disabled = false;
      }, 2000);
    } catch (err) {
      console.error('复制失败:', err);
      copyButton.textContent = '复制失败';
      setTimeout(() => {
        copyButton.textContent = '复制为公众号格式';
        copyButton.disabled = false;
      }, 2000);
    }
  });

  // 事件监听
  decreaseFont.addEventListener('click', () => {
    fontSize = Math.max(12, fontSize - 1);
    fontSizeDisplay.textContent = fontSize;
    themeManager.setFontSize(fontSize);
    updatePreview();
  });

  increaseFont.addEventListener('click', () => {
    fontSize = Math.min(24, fontSize + 1);
    fontSizeDisplay.textContent = fontSize;
    themeManager.setFontSize(fontSize);
    updatePreview();
  });

  themeSelect.addEventListener('change', (e) => {
    themeManager.setTheme(e.target.value);
    updatePreview();
  });

  fontSelect.addEventListener('change', (e) => {
    themeManager.setFont(e.target.value);
    updatePreview();
  });
  // 初始加载
  updatePreview();

  // 自定义下拉选择器初始化
  function initCustomSelect(selectElement) {
    const wrapper = document.createElement('div');
    wrapper.className = 'custom-select-wrapper';
    selectElement.parentNode.insertBefore(wrapper, selectElement);
    wrapper.appendChild(selectElement);

    const customSelect = document.createElement('div');
    customSelect.className = 'custom-select';
    customSelect.innerHTML = `
      <div class="custom-select-trigger">
        <span>${selectElement.options[selectElement.selectedIndex].text}</span>
        <div class="custom-select-arrow"></div>
      </div>
      <div class="custom-options"></div>
    `;
    wrapper.appendChild(customSelect);

    const optionsContainer = customSelect.querySelector('.custom-options');
    Array.from(selectElement.options).forEach(option => {
      const customOption = document.createElement('div');
      customOption.className = 'custom-option';
      customOption.textContent = option.text;
      customOption.dataset.value = option.value;
      if (option.selected) customOption.classList.add('selected');
      optionsContainer.appendChild(customOption);
    });

    // 事件处理
    const trigger = customSelect.querySelector('.custom-select-trigger');
    trigger.addEventListener('click', () => {
      customSelect.classList.toggle('open');
    });

    optionsContainer.addEventListener('click', (e) => {
      if (e.target.classList.contains('custom-option')) {
        const value = e.target.dataset.value;
        selectElement.value = value;
        trigger.querySelector('span').textContent = e.target.textContent;
        optionsContainer.querySelector('.selected')?.classList.remove('selected');
        e.target.classList.add('selected');
        customSelect.classList.remove('open');
        selectElement.dispatchEvent(new Event('change'));
      }
    });

    document.addEventListener('click', (e) => {
      if (!customSelect.contains(e.target)) {
        customSelect.classList.remove('open');
      }
    });
  }

  // 初始化自定义下拉选择器
  initCustomSelect(themeSelect);
  initCustomSelect(fontSelect);
  initialize();
});

// 添加打赏模态框到 HTML
document.body.insertAdjacentHTML('beforeend', `
  <div class="modal-overlay"></div>
  <div class="reward-modal">
    <span class="reward-modal-close">&times;</span>
    <h3>感谢支持</h3>
    <img src="/assets/reward-qr.png" alt="打赏二维码">
    <p>扫描二维码打赏作者</p>
  </div>
`);

// 打赏按钮点击事件
document.getElementById('rewardButton').addEventListener('click', () => {
  document.querySelector('.modal-overlay').style.display = 'block';
  document.querySelector('.reward-modal').style.display = 'block';
});

// 关闭模态框
document.querySelector('.reward-modal-close').addEventListener('click', () => {
  document.querySelector('.modal-overlay').style.display = 'none';
  document.querySelector('.reward-modal').style.display = 'none';
});

// 点击遮罩层关闭模态框
document.querySelector('.modal-overlay').addEventListener('click', () => {
  document.querySelector('.modal-overlay').style.display = 'none';
  document.querySelector('.reward-modal').style.display = 'none';
});