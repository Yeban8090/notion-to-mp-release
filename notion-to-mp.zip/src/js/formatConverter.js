const FormatConverter = {
  convertNotionToWechat(notionContent) {
    const container = document.createElement('div');
    container.innerHTML = notionContent;
    
    // 转换各个块的结构
    this.convertHeadings(container);
    this.convertParagraphs(container);
    this.convertBulletLists(container);
    this.convertNumberedLists(container);
    this.convertCodeBlocks(container);
    this.convertQuotes(container);
    this.convertImages(container);
    this.convertTables(container);
    this.convertDividers(container);
    
    // 包装成微信支持的表格布局
    const wrappedContent = `
      <table width="100% !important" cellpadding="0" cellspacing="0" style="table-layout: fixed; border-collapse: collapse; border: none; margin: 0; padding: 0; max-width: 100vw;">
        <tr>
          <td style="word-break: break-all; padding: 0; margin: 0; line-height: 1.7; overflow-wrap: break-word; white-space: normal; border: none;">
            ${container.innerHTML}
          </td>
        </tr>
      </table>
    `;
    return wrappedContent;
  },

  convertHeadings(container) {
    const headingMap = {
      'notion-header-block': 'h1',
      'notion-sub_header-block': 'h2',
      'notion-sub_sub_header-block': 'h3'
    };

    Object.entries(headingMap).forEach(([notionClass, headingTag]) => {
      const headings = container.querySelectorAll(`.${notionClass}`);
      headings.forEach(heading => {
        const innerContent = heading.querySelector('[class*="notion-text-content"]') || 
                           heading.querySelector('[class*="notranslate"]');
        
        const newHeading = document.createElement(headingTag);
        newHeading.className = notionClass;
        newHeading.innerHTML = innerContent ? innerContent.innerHTML : heading.innerHTML;
        heading.parentNode.replaceChild(newHeading, heading);
      });
    });
  },

  convertParagraphs(container) {
    const paragraphs = container.querySelectorAll('.notion-text-block');
    paragraphs.forEach(p => {
      const innerContent = p.querySelector('[class*="notion-text-content"]') || 
                         p.querySelector('[class*="notranslate"]');
      
      const newP = document.createElement('p');
      newP.className = 'notion-text-block';
      
      // 处理空白段落
      const content = innerContent ? innerContent.innerHTML : p.innerHTML;
      newP.innerHTML = content.trim() === '' ? '<br>' : content.replace(/\n/g, '<br>');
      
      p.parentNode.replaceChild(newP, p);
    });
  },

  convertBulletLists(container) {
    const lists = container.querySelectorAll('.notion-bulleted_list-block');
    let currentUl = null;
    
    lists.forEach((list, index) => {
      const contentElement = list.querySelector('[class*="notion-text-content"]') || 
                           list.querySelector('[class*="notranslate"]');
      
      if (!contentElement) return;

      // 检查当前列表项与前一个列表项是否相邻
      const prevList = lists[index - 1];
      const isConnected = prevList && 
        Array.from(prevList.parentNode.children)
          .indexOf(prevList) + 1 === Array.from(list.parentNode.children).indexOf(list);

      // 如果不相邻，创建新的 ul
      if (!isConnected) {
        currentUl = document.createElement('ul');
        currentUl.className = 'notion-bulleted_list-wrapper';
        list.parentNode.insertBefore(currentUl, list);
      }

      const li = document.createElement('li');
      li.className = 'notion-bulleted_list-block';
      li.innerHTML = contentElement.innerHTML;
      currentUl.appendChild(li);

      list.remove();
    });
  },

  convertNumberedLists(container) {
    const lists = container.querySelectorAll('.notion-numbered_list-block');
    let currentOl = null;
    
    lists.forEach((list, index) => {
      const contentElement = list.querySelector('[class*="notion-text-content"]') || 
                           list.querySelector('[class*="notranslate"]');
      
      if (!contentElement) return;

      // 检查当前列表项与前一个列表项是否相邻
      const prevList = lists[index - 1];
      const isConnected = prevList && 
        Array.from(prevList.parentNode.children)
          .indexOf(prevList) + 1 === Array.from(list.parentNode.children).indexOf(list);

      // 如果不相邻，创建新的 ol
      if (!isConnected) {
        currentOl = document.createElement('ol');
        currentOl.className = 'notion-numbered_list-wrapper';
        list.parentNode.insertBefore(currentOl, list);
      }

      const li = document.createElement('li');
      li.className = 'notion-numbered_list-block';
      li.innerHTML = contentElement.innerHTML;
      currentOl.appendChild(li);

      list.remove();
    });
  },

  convertCodeBlocks(container) {
    const codeBlocks = container.querySelectorAll('[class*="notion-code-block"]');
    codeBlocks.forEach(block => {
      const codeContent = block.querySelector('[class*="Code-"]')?.innerText || 
                         block.querySelector('code')?.innerText || 
                         block.innerText || '';
      
      const newPre = document.createElement('pre');
      const newCode = document.createElement('code');
      newCode.textContent = codeContent.trim();
      
      newPre.appendChild(newCode);
      block.parentNode.replaceChild(newPre, block);
    });
  },

  convertDividers(container) {
    // 修改选择器以匹配完整的类名
    const dividers = container.querySelectorAll('.notion-divider-block');
    dividers.forEach(divider => {
      const newDivider = document.createElement('div');
      // 保持完整的类名
      newDivider.className = 'notion-divider-block';
      
      const hr = document.createElement('hr');
      newDivider.appendChild(hr);
      
      divider.parentNode.replaceChild(newDivider, divider);
    });
  },

  convertQuotes(container) {
    const quotes = container.querySelectorAll('.notion-quote-block');
    quotes.forEach(quote => {
      const contentElement = quote.querySelector('[class*="notion-text-content"]') || 
                           quote.querySelector('[class*="notranslate"]');
      
      if (!contentElement) return;
      
      const newQuote = document.createElement('blockquote');
      newQuote.className = 'notion-quote-block';
      newQuote.innerHTML = contentElement.innerHTML;
      quote.parentNode.replaceChild(newQuote, quote);
    });
  },

  convertImages(container) {
    const imageBlocks = container.querySelectorAll('.notion-image-block');
    imageBlocks.forEach(block => {
      const img = block.querySelector('img');
      if (!img?.src) return;
      
      const figure = document.createElement('figure');
      figure.className = 'notion-image-block';
      
      const newImg = document.createElement('img');
      newImg.src = img.src;
      
      figure.appendChild(newImg);
      block.parentNode.replaceChild(figure, block);
    });
  },

  convertTables(container) {
    const tables = container.querySelectorAll('.notion-table-block');
    tables.forEach(tableBlock => {
      const table = tableBlock.querySelector('table');
      if (!table) return;
      
      const newTable = document.createElement('table');
      newTable.className = 'notion-table-block';
      newTable.innerHTML = table.innerHTML;
      
      tableBlock.parentNode.replaceChild(newTable, tableBlock);
    });
  }
};

window.FormatConverter = FormatConverter;