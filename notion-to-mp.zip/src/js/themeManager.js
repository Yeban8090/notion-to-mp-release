import defaultTheme from '/src/js/themes/defaultTheme.js';
import minimalistTheme from '/src/js/themes/minimalistTheme.js';
import elegantTheme from '/src/js/themes/elegantTheme.js';
import darkTheme from '/src/js/themes/darkTheme.js';
import academicTheme from '/src/js/themes/academicTheme.js';
import yebanTheme from '/src/js/themes/yebanTheme.js';
import aliTheme from '/src/js/themes/aliTheme.js';

const themes = {
  default: defaultTheme,
  minimalist: minimalistTheme,
  elegant: elegantTheme,
  dark: darkTheme,
  academic: academicTheme,
  yeban: yebanTheme,
  ali: aliTheme  // 添加阿篱主题
};

class ThemeManager {
  constructor() {
    this.currentTheme = 'default';
    this.currentFontSize = 16;
    this.currentFont = 'font-pingfang';
  }

  setTheme(themeName) {
    if (themes[themeName]) {
      this.currentTheme = themeName;
      return true;
    }
    return false;
  }

  getCurrentThemeStyles() {
    const styles = themes[this.currentTheme].styles;
    const fontSizeRatio = this.currentFontSize / 16;
    
    return {
      ...styles,
      h1: { ...styles.h1, fontSize: `${parseInt(styles.h1.fontSize) * fontSizeRatio}px` },
      h2: { ...styles.h2, fontSize: `${parseInt(styles.h2.fontSize) * fontSizeRatio}px` },
      h3: { ...styles.h3, fontSize: `${parseInt(styles.h3.fontSize) * fontSizeRatio}px` },
      h4: { ...styles.h4, fontSize: `${parseInt(styles.h4.fontSize) * fontSizeRatio}px` },
      paragraph: { ...styles.paragraph, fontSize: `${parseInt(styles.paragraph.fontSize) * fontSizeRatio}px` },
      list: { ...styles.list, fontSize: `${parseInt(styles.list.fontSize || '16') * fontSizeRatio}px` },
      code: { 
        ...styles.code, 
        fontSize: `${parseInt(styles.code.fontSize) * fontSizeRatio}px`,
        pre: {
          ...styles.code.pre,
          fontSize: `${parseInt(styles.code.fontSize) * fontSizeRatio}px`
        }
      },
      blockquote: { ...styles.blockquote, fontSize: `${parseInt(styles.blockquote.fontSize) * fontSizeRatio}px` },
    };
  }

  setFontSize(size) {
    this.currentFontSize = size;
    // 触发重新应用样式
    if (this.lastElement) {
      this.applyThemeToElement(this.lastElement);
    }
  }

  applyThemeToElement(element) {
    const styles = this.getCurrentThemeStyles();
    this.lastElement = element;
    
    // 初始化设置
    const table = element.querySelector('table');
    if (!table) return;
    
    const fontClasses = ['font-pingfang', 'font-simsun', 'font-simhei', 'font-kaiti', 'font-yahei'];
    element.classList.remove(...fontClasses);

    // 清除除段落外的其他元素的颜色样式
    element.querySelectorAll('*').forEach(el => {
      if (el.style) {
        const isTextBlock = el.classList.contains('notion-text-block');
        const hasTextBlockParent = el.closest('.notion-text-block');
        
        // 如果元素本身不是文本块，且不在文本块内部，则清除样式
        if (!isTextBlock && !hasTextBlockParent) {
          el.style.removeProperty('color');
          el.style.removeProperty('background-color');
          el.style.removeProperty('border-color');
        }
      }
    });

    // 设置基础表格样式
    table.style.cssText = `
      width: 100% !important;
      cellpadding="0";
      cellspacing="0";
      table-layout: fixed;
      border-radius: 8px;
      border-collapse: collapse;
      border: none;
      margin: 0; 
      padding: 0; 
      max-width: 100vw;
      overflow: hidden;
      font-family: ${
        this.currentFont === 'font-pingfang' ? 'Optima-Regular, Optima, PingFangSC-light, PingFangTC-light, "PingFang SC", Cambria, Cochin, Georgia, Times, "Times New Roman", serif' : 
        this.currentFont === 'font-simsun' ? 'SimSun, "宋体", serif' :
        this.currentFont === 'font-simhei' ? 'SimHei, "黑体", sans-serif' :
        this.currentFont === 'font-kaiti' ? 'KaiTi, "楷体", serif' :
        this.currentFont === 'font-yahei' ? '"Microsoft YaHei", "微软雅黑", sans-serif' : 
        '-apple-system, "PingFang SC", sans-serif'
      };
    `;

    table.querySelectorAll('td').forEach(td => {
      td.style.cssText = `
        word-break: break-all;
        padding: 0;
        margin: 0;
        line-height: 1.7;
        overflow-wrap: break-word;
        white-space: normal;
        border: none;
      `;
    });

    // 1. 标题样式（h1-h4）
    // 标题样式设置部分需要更新
    element.querySelectorAll('h1.notion-header-block').forEach(h => {
      h.style.cssText = `
        font-size: ${styles.h1.fontSize};
        font-weight: ${styles.h1.fontWeight};
        color: ${styles.h1.color};
        margin-bottom: ${styles.h1.marginBottom};
        padding-bottom: ${styles.h1.paddingBottom};
        border-bottom: ${styles.h1.borderBottom};
        text-shadow: ${styles.h1.textShadow};
        line-height: 1.5;
        display: block;
      `;
    });
    
    element.querySelectorAll('h2.notion-sub_header-block').forEach(h => {
      h.style.cssText = `
        font-size: ${styles.h2.fontSize};
        font-weight: ${styles.h2.fontWeight};
        color: ${styles.h2.color};
        margin-bottom: ${styles.h2.marginBottom};
        padding-bottom: ${styles.h2.paddingBottom};
        border-bottom: ${styles.h2.borderBottom};
        text-shadow: ${styles.h2.textShadow};
        line-height: 1.5;
        display: block;
      `;
    });
    
    element.querySelectorAll('h3.notion-sub_sub_header-block').forEach(h => {
      h.style.cssText = `
        font-size: ${styles.h3.fontSize};
        font-weight: ${styles.h3.fontWeight};
        color: ${styles.h3.color};
        margin-bottom: ${styles.h3.marginBottom};
        padding-bottom: ${styles.h3.paddingBottom};
        border-bottom: ${styles.h3.borderBottom};
        text-shadow: ${styles.h3.textShadow};
        line-height: 1.5;
        display: block;
      `;
    });
    
    element.querySelectorAll('h4.notion-sub_sub_header-block').forEach(h => {
      h.style.cssText = `
        font-size: ${styles.h4.fontSize};
        font-weight: ${styles.h4.fontWeight};
        color: ${styles.h4.color};
        margin-bottom: ${styles.h4.marginBottom};
        padding-bottom: ${styles.h4.paddingBottom};
        border-bottom: ${styles.h4.borderBottom};
        text-shadow: ${styles.h4.textShadow};
        line-height: 1.5;
        display: block;
      `;
    });

    // 2. 段落样式
    element.querySelectorAll('p.notion-text-block').forEach(p => {
      p.style.cssText = `
        font-size: ${styles.paragraph.fontSize};
        color: ${styles.paragraph.color};
        line-height: ${styles.paragraph.lineHeight};
        margin-bottom: ${styles.paragraph.marginBottom};
        display: block;
        ${styles.paragraph.textAlign ? `text-align: ${styles.paragraph.textAlign};` : ''}
        ${styles.paragraph.letterSpacing ? `letter-spacing: ${styles.paragraph.letterSpacing};` : ''}
      `;
    });

    // 3. 引用块样式
    element.querySelectorAll('blockquote.notion-quote-block').forEach(quote => {
      quote.style.cssText = `
        border-left: ${styles.blockquote.borderLeft};
        ${styles.blockquote.borderRight ? `border-right: ${styles.blockquote.borderRight};` : ''}
        padding: ${styles.blockquote.padding};
        color: ${styles.blockquote.color};
        margin: ${styles.blockquote.margin};
        font-size: ${styles.blockquote.fontSize};
        line-height: ${styles.blockquote.lineHeight};
        background-color: ${styles.blockquote.backgroundColor};
        border-radius: ${styles.blockquote.borderRadius};
        font-style: ${styles.blockquote.fontStyle || 'normal'};
      `;
    });

    // 4. 代码块样式
    element.querySelectorAll('[class*="notion-code-block"], pre').forEach(block => {
      block.style.cssText = `
        background-color: ${styles.code.backgroundColor};
        padding: ${styles.code.padding};
        border-radius: ${styles.code.borderRadius};
        font-family: ${styles.code.fontFamily};
        font-size: ${styles.code.fontSize};
        margin: ${styles.code.margin};
        line-height: ${styles.code.lineHeight};
        color: ${styles.code.color};
        border: ${styles.code.border};
        overflow-x: auto;
        position: relative;
        ${styles.code.boxShadow ? `box-shadow: ${styles.code.boxShadow};` : ''}
      `;

      let indicator = block.querySelector('.code-indicators');
      if (!indicator) {
        indicator = document.createElement('div');
        indicator.className = 'code-indicators';
      }
      
      const indicatorStyles = styles.code.indicators;
      indicator.style.cssText = `
        content: "";
        top: ${indicatorStyles.top};
        left: ${indicatorStyles.left};
        width: ${indicatorStyles.width};
        height: ${indicatorStyles.height};
        border-radius: ${indicatorStyles.borderRadius};
        background-color: ${indicatorStyles.backgroundColor};
        box-shadow: ${indicatorStyles.boxShadow};
        display: ${indicatorStyles.display};
      `;

      if (!block.contains(indicator)) {
        block.insertBefore(indicator, block.firstChild);
      }
    });

    // 5. 列表样式
    element.querySelectorAll('.notion-bulleted_list-wrapper, .notion-numbered_list-wrapper').forEach(list => {
      list.style.cssText = `
        margin: ${styles.list.margin};
        padding-left: ${styles.list.paddingLeft};
        ${styles.list.listStyleType ? `list-style-type: ${styles.list.listStyleType};` : ''}
      `;
      
      list.querySelectorAll('li').forEach(item => {
        item.style.cssText = `
          font-size: ${styles.list.fontSize};
          color: ${styles.list.color};
          line-height: ${styles.list.lineHeight};
          margin: ${styles.list.itemMargin};
          ${styles.list.itemSpacing ? `margin-bottom: ${styles.list.itemSpacing};` : ''}
        `;
      });
    });

    // 6. 表格样式
    element.querySelectorAll('table.notion-table-block').forEach(table => {
      table.style.cssText = `
        border-collapse: collapse;
        width: 100%;
        margin: ${styles.table.margin};
        border-radius: ${styles.table.borderRadius};
        overflow: hidden;
        border: ${styles.table.border};
        ${styles.table.boxShadow ? `box-shadow: ${styles.table.boxShadow};` : ''}
      `;

      table.querySelectorAll('td, th').forEach(cell => {
        cell.style.cssText = `
          border: ${styles.table.cell.border};
          padding: ${styles.table.cell.padding};
          text-align: ${styles.table.cell.textAlign};
          color: ${styles.table.cell.color};
          ${styles.table.cell.verticalAlign ? `vertical-align: ${styles.table.cell.verticalAlign};` : ''}
        `;
      });
    });

    // 7. 分割线样式
    element.querySelectorAll('.notion-selectable.notion-divider-block, .notion-divider-block').forEach(divider => {
      divider.style.cssText = `
        padding: 0;
        width: 100%;
        text-align: center;
        margin: ${styles.divider.margin};
      `;
      
      const hr = divider.querySelector('hr');
      if (hr) {
        hr.style.cssText = `
          width: 100%;
          height: ${styles.divider.height || '2px'};
          border: none;
          border-radius: ${styles.divider.borderRadius};
          background: ${styles.divider.background};
          margin: 0 auto;
          padding: 0;
        `;
      }
    });

    // 8. 图片样式
    element.querySelectorAll('figure.notion-image-block').forEach(figure => {
      figure.style.cssText = `
        margin: ${styles.image.margin};
      `;
      
      const img = figure.querySelector('img');
      if (img) {
        img.style.cssText = `
          max-width: 100%;
          height: auto;
          display: block;
          border-radius: ${styles.image.borderRadius};
          ${styles.image.boxShadow ? `box-shadow: ${styles.image.boxShadow};` : ''}
        `;
      }
    });
  }

  setFont(font) {
    this.currentFont = font;
  }
}

export { themes };
export default new ThemeManager();
