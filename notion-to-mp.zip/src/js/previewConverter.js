const PreviewConverter = {
  async copyWithFormat(content) {
    if (!content) {
      console.error('复制失败：内容为空');
      return false;
    }
    try {
      const editable = document.createElement('div');
      editable.contentEditable = true;
      editable.style.position = 'absolute';
      editable.style.left = '-9999px';

      const tempDiv = document.createElement('div');
      tempDiv.innerHTML = content;

      // 处理图片
      const images = tempDiv.getElementsByTagName('img');
      for (const img of images) {
        if (img.src) {
          try {
            const response = await fetch(img.src);
            if (!response.ok) {
              throw new Error(`图片加载失败: ${response.status} ${response.statusText}`);
            }
            const blob = await response.blob();
            const reader = new FileReader();
            await new Promise((resolve, reject) => {
              reader.onload = () => {
                img.src = reader.result;
                resolve();
              };
              reader.onerror = (error) => {
                reject(new Error(`图片转换失败: ${error.message}`));
              };
              reader.readAsDataURL(blob);
            });
          } catch (error) {
            console.error('图片处理失败:', error.message);
            // 可以选择在这里设置一个默认图片或者移除失败的图片
            img.remove();
          }
        }
      }
      console.log('复制成功！');
      editable.innerHTML = tempDiv.innerHTML;

      document.body.appendChild(editable);

      try {
        const range = document.createRange();
        range.selectNodeContents(editable);
        const selection = window.getSelection();
        selection.removeAllRanges();
        selection.addRange(range);

        const success = document.execCommand('copy');
        if (!success) {
          throw new Error('复制命令执行失败');
        }

        return true;
      } catch (error) {
        console.error('复制操作失败:', error.message);
        return false;
      } finally {
        document.body.removeChild(editable);
        window.getSelection().removeAllRanges();
      }
    } catch (error) {
      console.error('内容处理失败:', error.message);
      return false;
    }
  }
};

window.PreviewConverter = PreviewConverter;