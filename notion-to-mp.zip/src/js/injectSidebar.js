(function() {
  // 检查是否已存在侧边栏
  if (document.getElementById('notion-to-mp-sidebar')) {
    return;
  }

  // 创建侧边栏容器
  const sidebar = document.createElement('iframe');
  sidebar.id = 'notion-to-mp-sidebar';
  sidebar.src = chrome.runtime.getURL('src/html/sidebar.html');
  
  // 计算浏览器内页高度
  const viewportHeight = window.innerHeight;
  
  sidebar.style.cssText = `
    position: fixed;
    top: 0;
    right: 0;
    width: 700px;  /* 增加宽度 */
    height: ${viewportHeight}px;
    border: none;
    z-index: 9999;
    transform: translateX(100%);
    transition: transform 0.3s ease-out;
    box-shadow: -2px 0 8px rgba(0, 0, 0, 0.1);
    background: #fff;
  `;

  document.body.appendChild(sidebar);

  setTimeout(() => {
    sidebar.style.transform = 'translateX(0)';
  }, 100);

  // 点击页面其他区域关闭侧边栏
  document.addEventListener('click', (e) => {
    const sidebarElement = document.getElementById('notion-to-mp-sidebar');
    if (sidebarElement && !sidebarElement.contains(e.target)) {
      sidebarElement.style.transform = 'translateX(100%)';
      setTimeout(() => {
        if (sidebarElement && sidebarElement.parentNode) {
          sidebarElement.parentNode.removeChild(sidebarElement);
        }
      }, 300);
    }
  }, true);

  // 监听窗口大小变化
  window.addEventListener('resize', () => {
    const sidebarElement = document.getElementById('notion-to-mp-sidebar');
    if (sidebarElement) {
      sidebarElement.style.height = `${window.innerHeight}px`;
    }
  });
})();