const aliTheme = {
  name: '阿篱主题',
  styles: {
    h1: {
      fontSize: '24px',
      fontWeight: '600',
      color: '#0f7850',
      marginBottom: '24px',
      paddingBottom: '12px',
      borderBottom: 'none',
      textShadow: '0 2px 4px rgba(15, 120, 80, 0.1)'
    },
    h2: {
      fontSize: '20px',
      fontWeight: '600',
      color: '#148a5c',
      marginBottom: '20px',
      paddingBottom: '8px',
      borderBottom: 'none',
      textShadow: '0 1px 2px rgba(15, 120, 80, 0.08)'
    },
    h3: {
      fontSize: '18px',
      fontWeight: '600',
      color: '#199c68',
      marginBottom: '16px',
      paddingBottom: '6px',
      borderBottom: 'none'
    },
    h4: {
      fontSize: '16px',
      fontWeight: '600',
      color: '#1eae74',
      marginBottom: '12px',
      paddingBottom: '4px',
      borderBottom: 'none'
    },
    paragraph: {
      fontSize: '16px',
      color: '#2c3e50',
      lineHeight: '1.8',
      marginBottom: '16px',
      letterSpacing: '0.5px'
    },
    blockquote: {
      borderLeft: '4px solid #0f7850',
      borderRight: '1px solid rgba(15, 120, 80, 0.1)',
      padding: '12px 16px',
      color: '#0f7850',
      margin: '20px 0',
      fontSize: '15px',
      lineHeight: '1.7',
      backgroundColor: 'rgba(15, 120, 80, 0.05)',
      borderRadius: '0 4px 4px 0',
      fontStyle: 'italic'
    },
    code: {
      backgroundColor: 'rgba(15, 120, 80, 0.03)',
      padding: '16px',
      borderRadius: '8px',
      fontFamily: 'Menlo, Monaco, Consolas, "Courier New", monospace',
      fontSize: '14px',
      margin: '16px 0',
      lineHeight: '1.6',
      color: '#2c3e50',
      border: '1px solid rgba(15, 120, 80, 0.1)',
      boxShadow: '0 2px 4px rgba(15, 120, 80, 0.05)',
      indicators: {
        top: '12px',
        left: '12px',
        width: '12px',
        height: '12px',
        borderRadius: '50%',
        backgroundColor: '#ff5f56',
        boxShadow: '20px 0 0 #ffbd2e, 40px 0 0 #27c93f',
        display: 'block'
      }
    },
    list: {
      fontSize: '16px',
      color: '#2c3e50',
      lineHeight: '1.8',
      margin: '16px 0',
      paddingLeft: '24px',
      itemMargin: '8px 0',
      itemSpacing: '8px'
    },
    table: {
      margin: '20px 0',
      borderRadius: '8px',
      border: '1px solid rgba(15, 120, 80, 0.1)',
      boxShadow: '0 2px 4px rgba(15, 120, 80, 0.05)',
      cell: {
        border: '1px solid rgba(15, 120, 80, 0.1)',
        padding: '12px 16px',
        textAlign: 'left',
        color: '#2c3e50',
        verticalAlign: 'middle'
      }
    },
    divider: {
      margin: '32px 0',
      height: '2px',
      borderRadius: '2px',
      background: 'linear-gradient(90deg, rgba(15, 120, 80, 0) 0%, #0f7850 50%, rgba(15, 120, 80, 0) 100%)'
    },
    image: {
      margin: '24px 0',
      borderRadius: '8px',
      boxShadow: '0 4px 12px rgba(15, 120, 80, 0.1)'
    }
  }
};

export default aliTheme;