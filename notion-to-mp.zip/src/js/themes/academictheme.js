export default {
  name: '学术主题',
  styles: {
    h1: {
      fontSize: '26px',
      color: '#1a237e',  // 深蓝色
      fontWeight: 'bold',
      marginBottom: '24px',
      paddingBottom: '12px',
      borderBottom: '2px solid #e0e0e0',
      textShadow: '0 1px 1px rgba(26, 35, 126, 0.1)'
    },
    h2: {
      fontSize: '22px',
      color: '#283593',  // 稍浅的蓝色
      fontWeight: 'bold',
      marginBottom: '20px',
      paddingBottom: '8px',
      borderBottom: '1px solid #e0e0e0',
      textShadow: '0 1px 1px rgba(40, 53, 147, 0.05)'
    },
    h3: {
      fontSize: '20px',
      color: '#3949ab',  // 更浅的蓝色
      fontWeight: 'bold',
      marginBottom: '16px',
      paddingBottom: '4px',
      borderBottom: '1px solid #f0f0f0',
      textShadow: 'none'
    },
    h4: {
      fontSize: '18px',
      color: '#5c6bc0',  // 最浅的蓝色
      fontWeight: 'bold',
      marginBottom: '14px',
      paddingBottom: '2px',
      borderBottom: 'none',
      textShadow: 'none'
    },
    paragraph: {
      fontSize: '16px',
      lineHeight: '1.9',
      marginBottom: '16px',
      color: '#212121',
      textAlign: 'justify',
      letterSpacing: '0.3px'
    },
    blockquote: {
      borderLeft: '4px solid #3949ab',
      borderRight: '1px solid #e0e0e0',
      paddingLeft: '16px',
      color: '#424242',
      margin: '1.5em 0',
      fontSize: '16px',
      lineHeight: '1.8',
      backgroundColor: '#f5f5f5',
      padding: '16px 20px',
      borderRadius: '4px',
      position: 'relative',
      fontStyle: 'italic'
    },
    code: {
      backgroundColor: '#f5f5f5',
      padding: '10px 10px',
      borderRadius: '4px',
      fontFamily: 'SFMono-Regular, Consolas, Menlo, monospace',
      fontSize: '14px',
      position: 'relative',
      margin: '20px 0',
      lineHeight: '1.6',
      color: '#212121',
      border: '1px solid #e0e0e0',
      boxShadow: '0 1px 2px rgba(0, 0, 0, 0.05)',
      pre: {
        margin: '0',
        padding: '24px 16px 16px',
        whiteSpace: 'pre',
        overflowX: 'auto'
      },
      indicators: {
        content: '""',
        top: '12px',
        left: '12px',
        width: '12px',
        height: '12px',
        borderRadius: '50%',
        backgroundColor: '#9fa8da',
        boxShadow: '20px 0 0 #9fa8da, 40px 0 0 #9fa8da',
        display: 'block'
      }
    },
    list: {
      position: 'relative',
      paddingLeft: '1.5em',
      margin: '0.8em 0',
      lineHeight: '1.8',
      fontSize: '16px',
      color: '#212121',
      listStyleType: 'square',
      itemSpacing: '0.6em'
    },
    table: {
      borderCollapse: 'collapse',
      width: '100%',
      margin: '1.5em 0',
      borderRadius: '4px',
      overflow: 'hidden',
      border: '1px solid #e0e0e0',
      boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05)',
      cell: {
        border: '1px solid #e0e0e0',
        padding: '12px 16px',
        textAlign: 'left',
        color: '#212121',
        verticalAlign: 'middle'
      }
    },
    divider: {
      width: '100%',
      margin: '24px 0',
      borderRadius: '2px',
      height: '2px',
      background: 'linear-gradient(90deg, #3949ab 0%, rgba(57, 73, 171, 0.1) 100%)'
    },
    image: {
      maxWidth: '100%',
      height: 'auto',
      margin: '1px auto',
      display: 'block',
      borderRadius: '4px',
      boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)'
    }
  }
};