export default {
  name: '极简主题',
  styles: {
    h1: {
      fontSize: '26px',
      color: '#333333',
      fontWeight: '500',
      marginBottom: '28px',
      paddingBottom: '12px',
      borderBottom: '1px solid #f0f0f0',
      textShadow: 'none'
    },
    h2: {
      fontSize: '22px',
      color: '#444444',
      fontWeight: '500',
      marginBottom: '24px',
      paddingBottom: '8px',
      borderBottom: '1px solid #f5f5f5',
      textShadow: 'none'
    },
    h3: {
      fontSize: '20px',
      color: '#555555',
      fontWeight: '500',
      marginBottom: '20px',
      paddingBottom: '4px',
      textShadow: 'none'
    },
    h4: {
      fontSize: '18px',
      color: '#666666',
      fontWeight: '500',
      marginBottom: '16px',
      textShadow: 'none'
    },
    paragraph: {
      fontSize: '16px',
      lineHeight: '1.9',
      marginBottom: '20px',
      color: '#333333',
      textAlign: 'left',
      letterSpacing: '0.3px'
    },
    blockquote: {
      borderLeft: '2px solid #e0e0e0',
      paddingLeft: '20px',
      color: '#666666',
      margin: '2em 0',
      fontSize: '16px',
      lineHeight: '1.8',
      backgroundColor: '#fafafa',
      padding: '20px 24px',
      borderRadius: '2px',
      fontStyle: 'normal'
    },
    code: {
      backgroundColor: '#fafafa',
      padding: '10px 10px',
      borderRadius: '2px',
      fontFamily: 'SFMono-Regular, Consolas, Menlo, monospace',
      fontSize: '14px',
      position: 'relative',
      margin: '24px 0',
      lineHeight: '1.6',
      color: '#333333',
      border: '1px solid #f0f0f0',
      boxShadow: 'none',
      pre: {
        margin: '0',
        padding: '24px 16px 16px',
        whiteSpace: 'pre',
        overflowX: 'auto'
      },
      indicators: {
        content: '""',
        top: '12px',
        left: '12px',
        width: '8px',
        height: '8px',
        borderRadius: '50%',
        backgroundColor: '#cccccc',
        boxShadow: '16px 0 0 #cccccc, 32px 0 0 #cccccc',
        display: 'block'
      }
    },
    list: {
      position: 'relative',
      paddingLeft: '1.2em',
      margin: '1em 0',
      lineHeight: '1.9',
      fontSize: '16px',
      color: '#333333',
      listStyleType: 'none',
      itemSpacing: '0.8em'
    },
    table: {
      borderCollapse: 'collapse',
      width: '100%',
      margin: '2em 0',
      borderRadius: '2px',
      overflow: 'hidden',
      border: '1px solid #f0f0f0',
      boxShadow: 'none',
      cell: {
        border: '1px solid #f0f0f0',
        padding: '14px 18px',
        textAlign: 'left',
        color: '#333333',
        verticalAlign: 'middle'
      }
    },
    divider: {
      width: '100%',
      margin: '32px 0',
      height: '1px',
      background: '#f0f0f0'
    },
    image: {
      maxWidth: '100%',
      height: 'auto',
      margin: '24px auto',
      display: 'block',
      borderRadius: '2px',
      boxShadow: 'none'
    }
  }
};