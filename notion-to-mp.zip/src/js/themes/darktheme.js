export default {
  name: '深色主题',
  styles: {
    h1: {
      fontSize: '28px',
      color: '#88ccff',
      fontWeight: '600',
      marginBottom: '28px',
      paddingBottom: '12px',
      borderBottom: '2px solid #2d3748',
      textShadow: '0 1px 2px rgba(136, 204, 255, 0.2)'
    },
    h2: {
      fontSize: '24px',
      color: '#63b3ed',
      fontWeight: '600',
      marginBottom: '24px',
      paddingBottom: '8px',
      borderBottom: '1px solid #2d3748',
      textShadow: '0 1px 1px rgba(99, 179, 237, 0.15)'
    },
    h3: {
      fontSize: '20px',
      color: '#4299e1',
      fontWeight: '600',
      marginBottom: '20px',
      paddingBottom: '4px',
      borderBottom: '1px solid #2d3748'
    },
    h4: {
      fontSize: '18px',
      color: '#3182ce',
      fontWeight: '600',
      marginBottom: '16px'
    },
    paragraph: {
      fontSize: '16px',
      lineHeight: '1.85',
      marginBottom: '18px',
      color: '#2c3e50',
      textAlign: 'justify',
      letterSpacing: '0.3px'
    },
    blockquote: {
      borderLeft: '4px solid #4299e1',
      borderRight: '1px solid #2d3748',
      paddingLeft: '18px',
      color: '#a0aec0',
      margin: '2em 0',
      fontSize: '16px',
      lineHeight: '1.8',
      backgroundColor: '#2d3748',
      padding: '18px 24px',
      borderRadius: '4px',
      fontStyle: 'italic'
    },
    code: {
      backgroundColor: '#2d3748',
      padding: '10px 10px',
      borderRadius: '6px',
      fontFamily: 'SFMono-Regular, Consolas, Menlo, monospace',
      fontSize: '14px',
      position: 'relative',
      margin: '20px 0',
      lineHeight: '1.6',
      color: '#e2e8f0',
      border: '1px solid #4a5568',
      boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)',
      pre: {
        margin: '0',
        padding: '24px 16px 16px',
        whiteSpace: 'pre',
        overflowX: 'auto'
      },
      indicators: {
        content: '""',
        top: '12px',
        left: '12px',
        width: '10px',
        height: '10px',
        borderRadius: '50%',
        backgroundColor: '#e53e3e',
        boxShadow: '18px 0 0 #ecc94b, 36px 0 0 #48bb78',
        display: 'block'
      }
    },
    list: {
      position: 'relative',
      paddingLeft: '1.6em',
      margin: '1em 0',
      lineHeight: '1.85',
      fontSize: '16px',
      color: '#2c3e50',
      listStyleType: 'disc',
      itemSpacing: '0.7em'
    },
    table: {
      borderCollapse: 'collapse',
      width: '100%',
      margin: '2em 0',
      borderRadius: '6px',
      overflow: 'hidden',
      border: '1px solid #2d3748',
      boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)',
      cell: {
        border: '1px solid #2d3748',
        padding: '14px 20px',
        textAlign: 'left',
        color: '#e2e8f0',
        verticalAlign: 'middle'
      }
    },
    divider: {
      width: '100%',
      margin: '32px 0',
      height: '1px',
      background: 'linear-gradient(90deg, #4299e1 0%, rgba(66, 153, 225, 0.1) 100%)'
    },
    image: {
      maxWidth: '100%',
      height: 'auto',
      margin: '24px auto',
      display: 'block',
      borderRadius: '6px',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.3)'
    }
  }
};