export default {
  name: '夜半主题',
  styles: {
    h1: {
      fontSize: '28px',
      color: '#553c9a',  // 深紫色
      fontWeight: '600',
      marginBottom: '32px',
      paddingBottom: '16px',
      borderBottom: '2px solid #e9d8fd',
      textShadow: '0 1px 2px rgba(85, 60, 154, 0.1)'
    },
    h2: {
      fontSize: '24px',
      color: '#6b46c1',  // 中紫色
      fontWeight: '600',
      marginBottom: '28px',
      paddingBottom: '12px',
      borderBottom: '1px solid #e9d8fd',
      textShadow: '0 1px 1px rgba(107, 70, 193, 0.05)'
    },
    h3: {
      fontSize: '20px',
      color: '#7a7da0',  // 浅紫色
      fontWeight: '600',
      marginBottom: '20px',
      paddingBottom: '8px',
      borderBottom: '1px solid #f3e8ff'
    },
    h4: {
      fontSize: '18px',
      color: '#9f7aea',  // 最浅紫色
      fontWeight: '600',
      marginBottom: '20px'
    },
    paragraph: {
      fontSize: '16px',
      lineHeight: '2',
      marginBottom: '24px',
      color: '#2d3748',
      textAlign: 'justify',
      letterSpacing: '0.4px',
      textIndent: '2em'  // 添加首行缩进
    },
    blockquote: {
      borderLeft: '4px solid #6b46c1',  // 更新引用块边框颜色
      borderRight: '1px solid #edf2f7',
      paddingLeft: '20px',
      color: '#4a5568',
      margin: '2em 0',
      fontSize: '16px',
      lineHeight: '1.9',
      backgroundColor: '#f8fafc',
      padding: '20px 24px',
      borderRadius: '8px',
      position: 'relative',
      fontStyle: 'normal',
      boxShadow: '0 2px 4px rgba(0, 0, 0, 0.05)'
    },
    code: {
      backgroundColor: '#f8fafc',
      padding: '24px 20px',
      borderRadius: '8px',
      fontFamily: 'SFMono-Regular, Consolas, Menlo, monospace',
      fontSize: '14px',
      position: 'relative',
      margin: '24px 0',
      lineHeight: '1.7',
      color: '#2d3748',
      border: '1px solid #edf2f7',
      boxShadow: '0 2px 4px rgba(0, 0, 0, 0.05)',
      whiteSpace: 'pre',
      overflowX: 'auto',
      indicators: {
        content: '""',
        top: '12px',
        left: '12px',
        width: '10px',
        height: '10px',
        borderRadius: '50%',
        backgroundColor: '#718096',
        boxShadow: '20px 0 0 #a0aec0, 40px 0 0 #cbd5e0',
        display: 'block'
      }
    },
    list: {
      position: 'relative',
      paddingLeft: '2em',
      margin: '1.2em 0',
      lineHeight: '2',
      fontSize: '16px',
      color: '#2d3748',
      listStyleType: '•',  // 自定义列表符号
      itemSpacing: '0.8em'
    },
    table: {
      borderCollapse: 'collapse',
      width: '100%',
      margin: '2em 0',
      borderRadius: '8px',
      overflow: 'hidden',
      border: '1px solid #edf2f7',
      boxShadow: '0 2px 4px rgba(0, 0, 0, 0.05)',
      cell: {
        border: '1px solid #edf2f7',
        padding: '16px 20px',
        textAlign: 'left',
        color: '#2d3748',
        verticalAlign: 'middle'
      }
    },
    divider: {
      width: '100%',
      margin: '32px 0',
      borderRadius: '2px',
      height: '2px',
      background: 'linear-gradient(90deg, #2d3748 0%, #edf2f7 100%)'
    },
    image: {
      maxWidth: '100%',
      height: 'auto',
      margin: '24px auto',
      display: 'block',
      borderRadius: '8px',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)'
    }
  }
};