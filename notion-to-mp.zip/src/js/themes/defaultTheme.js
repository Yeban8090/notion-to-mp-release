export default {
  name: '默认主题',
  styles: {
    h1: {
      fontSize: '26px',
      color: '#2563eb',
      fontWeight: 'bold',
      marginBottom: '24px',
      paddingBottom: '12px',
      borderBottom: 'none',
      textShadow: '0 1px 2px rgba(37, 99, 235, 0.1)'
    },
    h2: {
      fontSize: '22px',
      color: '#3b82f6',
      fontWeight: 'bold',
      marginBottom: '20px',
      paddingBottom: '8px',
      borderBottom: 'none',
      textShadow: '0 1px 1px rgba(59, 130, 246, 0.05)'
    },
    h3: {
      fontSize: '20px',
      color: '#60a5fa',
      fontWeight: 'bold',
      marginBottom: '16px',
      paddingBottom: '4px',
      borderBottom: 'none',
      textShadow: 'none'
    },
    h4: {
      fontSize: '18px',
      color: '#93c5fd',
      fontWeight: 'bold',
      marginBottom: '14px',
      paddingBottom: '2px',
      borderBottom: 'none',
      textShadow: 'none'
    },
    paragraph: {
      fontSize: '16px',
      lineHeight: '1.8',
      marginBottom: '16px',
      color: '#374151',  // 深灰色，易读
      textAlign: 'justify',  // 两端对齐
      letterSpacing: '0.2px'  // 轻微字间距
    },
    blockquote: {
      borderLeft: '4px solid #3b82f6',
      borderRight: '1px solid #e5e7eb',  // 添加右边框
      paddingLeft: '16px',
      color: '#4b5563',
      margin: '1.5em 0',
      fontSize: '16px',
      lineHeight: '1.7',
      backgroundColor: '#f8fafc',
      padding: '16px 20px',
      borderRadius: '6px',
      position: 'relative',  // 为引号做准备
      fontStyle: 'italic'  // 斜体
    },
    code: {
      backgroundColor: '#f8fafc',
      padding: '10px 10px',
      borderRadius: '8px',
      fontFamily: 'SFMono-Regular, Consolas, Menlo, monospace',
      fontSize: '14px',
      position: 'relative',
      margin: '20px 0',
      lineHeight: '1.6',
      color: '#374151',
      border: '1px solid #e5e7eb',
      boxShadow: '0 1px 2px rgba(0, 0, 0, 0.05)',  // 添加微妙的阴影
      pre: {
        margin: '0',
        padding: '24px 16px 16px',
        whiteSpace: 'pre',
        overflowX: 'auto'
      },
      indicators: {
        content: '""',
        top: '12px',
        left: '12px',
        width: '12px',
        height: '12px',
        borderRadius: '50%',
        backgroundColor: '#ff5f56',
        boxShadow: '20px 0 0 #ffbd2e, 40px 0 0 #27c93f',
        display: 'block'
      }
    },
    list: {
      position: 'relative',
      paddingLeft: '1.5em',
      margin: '0.8em 0',
      lineHeight: '1.8',
      fontSize: '16px',
      color: '#374151',
      listStyleType: 'circle',  // 圆形列表符号
      itemSpacing: '0.5em'  // 列表项间距
    },
    table: {
      borderCollapse: 'collapse',
      width: '100%',
      margin: '1.5em 0',
      borderRadius: '8px',
      overflow: 'hidden',
      border: '1px solid #e5e7eb',
      boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05)',  // 添加表格阴影
      cell: {
        border: '1px solid #e5e7eb',
        padding: '12px 16px',
        textAlign: 'left',
        color: '#374151',
        verticalAlign: 'middle'  // 垂直居中
      }
    },
    divider: {
      width: '100%',
      margin: '24px 0',
      borderRadius: '4px',
      height: '2px',  // 增加分割线高度
      background: 'linear-gradient(90deg, #2563eb 0%, rgba(37, 99, 235, 0.1) 100%)'
    },
    image: {
      maxWidth: '100%',
      height: 'auto',
      margin: '1px auto',
      display: 'block',
      borderRadius: '8px',
      boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)'  // 添加图片阴影
    }
  }
};