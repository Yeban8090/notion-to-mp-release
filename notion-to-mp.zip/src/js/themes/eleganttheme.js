export default {
  name: '优雅主题',
  styles: {
    h1: {
      fontSize: '28px',
      color: '#1a5f7a',
      fontWeight: '600',
      marginBottom: '28px',
      paddingBottom: '12px',
      borderBottom: '2px solid #e2eef3',
      textShadow: '0 1px 2px rgba(26, 95, 122, 0.1)'
    },
    h2: {
      fontSize: '24px',
      color: '#2c7a9c',
      fontWeight: '600',
      marginBottom: '24px',
      paddingBottom: '8px',
      borderBottom: '1px solid #e2eef3',
      textShadow: '0 1px 1px rgba(44, 122, 156, 0.05)'
    },
    h3: {
      fontSize: '20px',
      color: '#3d8ba9',
      fontWeight: '600',
      marginBottom: '20px',
      paddingBottom: '4px',
      borderBottom: '1px solid #f0f7fa'
    },
    h4: {
      fontSize: '18px',
      color: '#4e9cb6',
      fontWeight: '600',
      marginBottom: '16px'
    },
    paragraph: {
      fontSize: '16px',
      lineHeight: '1.85',
      marginBottom: '18px',
      color: '#2c3e50',
      textAlign: 'justify',
      letterSpacing: '0.3px'
    },
    blockquote: {
      borderLeft: '4px solid #7fb9d1',
      borderRight: '1px solid #e2eef3',
      paddingLeft: '18px',
      color: '#34495e',
      margin: '2em 0',
      fontSize: '16px',
      lineHeight: '1.8',
      backgroundColor: '#f8fcfd',
      padding: '18px 24px',
      borderRadius: '4px',
      fontStyle: 'italic',
      position: 'relative'
    },
    code: {
      backgroundColor: '#f8fcfd',
      padding: '10px 10px',
      borderRadius: '6px',
      fontFamily: 'SFMono-Regular, Consolas, Menlo, monospace',
      fontSize: '14px',
      position: 'relative',
      margin: '20px 0',
      lineHeight: '1.6',
      color: '#2c3e50',
      border: '1px solid #e2eef3',
      boxShadow: '0 2px 4px rgba(0, 0, 0, 0.03)',
      pre: {
        margin: '0',
        padding: '24px 16px 16px',
        whiteSpace: 'pre',
        overflowX: 'auto'
      },
      indicators: {
        content: '""',
        top: '12px',
        left: '12px',
        width: '10px',
        height: '10px',
        borderRadius: '50%',
        backgroundColor: '#7fb9d1',
        boxShadow: '18px 0 0 #9ecadb, 36px 0 0 #bddbe7',
        display: 'block'
      }
    },
    list: {
      position: 'relative',
      paddingLeft: '1.6em',
      margin: '1em 0',
      lineHeight: '1.85',
      fontSize: '16px',
      color: '#2c3e50',
      listStyleType: 'disc',
      itemSpacing: '0.7em'
    },
    table: {
      borderCollapse: 'collapse',
      width: '100%',
      margin: '2em 0',
      borderRadius: '6px',
      overflow: 'hidden',
      border: '1px solid #e2eef3',
      boxShadow: '0 2px 4px rgba(0, 0, 0, 0.03)',
      cell: {
        border: '1px solid #e2eef3',
        padding: '14px 20px',
        textAlign: 'left',
        color: '#2c3e50',
        verticalAlign: 'middle'
      }
    },
    divider: {
      width: '100%',
      margin: '32px 0',
      height: '1px',
      background: 'linear-gradient(90deg, #7fb9d1 0%, rgba(127, 185, 209, 0.1) 100%)'
    },
    image: {
      maxWidth: '100%',
      height: 'auto',
      margin: '24px auto',
      display: 'block',
      borderRadius: '6px',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.05)'
    }
  }
};